  # TrabalhoUm

  Projeto de jogo "Supernatural : Morte Súbita". O jogo é do tipo text adventure, ou seja,é um jogo basicamente lógico com ações
básicas. para fins didáticos da disciplina de Práticas de Programação Orientada a Objetos - UFLA (Universisdade Federal de Lavra)

  A imersão na história começa… AGORA!

  Dean winchester está prioritariamente preocupado. Já haviam duas semanas que seu irmão Sam havia saído de casa para investigar um
caso de ataques de bruxas na cidade de Weston, no estado da Flórida. Seria apenas uma caçada a mais na vida de um hunter,
entretanto, Sam é um caçador extremamente experiente e um grupo de bruxas não deveria custar mais de poucos dias para ser resolvido.
Ao meio de um sono bastante turbulento, o telefone de Dean Winchester toca. Ele atende. Após alguns segundos de silêncio absoluto,
um ruído semelhante à um aparelho de rádio fora de sintonia toma conta do aparelho. Aos poucos uma voz bastante distorcida diz
algumas palavras que parecem estar em algum idioma desconhecido por ele : “Vala noocenoquedam quisrim tatstus. Hairo nai no
demonai, ainote shiros. Saisudore corena, naishteiros”. A frase se repete inúmeras vezes ao fundo. Rapidamente, Dean anota a frase
em um pedaço de papel. Ao fazer isto, Dean percebe que há um barulho estranho ao fundo do ambiente ao outro lado da linha. Um som
agudo, que vem e volta. Súbitamente ele identifica o ruído e entra em completo desespero: Era a voz de seu irmão, que gritava com
toda a força existente no seu peito. A ligação é desligada. Dean precisa salvar seu irmão, mas não sabe por onde começar.
Tudo que ele possui é a sua mochila e o diário de seu pai, que possui algumas informações preciosas. Sua mochila começa vazia e
ele pode acrescentar apenas três itens nela. Sabe-se que, em sua casa, Dean pode deixar guardado quantos itens quiser, em seu
armário. Sabe-se também que, a cada vez que Dean tem que se deslocar de um lugar para outro,ele precisa de 3 dias.  É seu papel
guiar Dean no caminho correto que salvará seu irmão.

  O Trabalho foi desenvolvido com java versão 8 utilizando o NetBeans IDE e NetBeans Platform que são baseados em software da
netbeans.org, que tem licenciamento duplo sob a Licença de Desenvolvimento e Distribuição Comum (CDDL) e a GNU General Public
License versão 2 com excepção do Classpath. 
  Product Version: NetBeans IDE 8.2 (Build 201609300101)
  Atualizações: O IDE NetBeans está atualizado para a versão NetBeans 8.2 Patch 2
  Java: 1.8.0_121; Java HotSpot(TM) 64-Bit Server VM 25.121-b13
  Runtime: Java(TM) SE Runtime Environment 1.8.0_121-b13
  System: Linux version 4.8.0-56-generic running on amd64; UTF-8; pt_BR (nb)
  User directory: /home/junior/.netbeans/8.2
  Cache directory: /home/junior/.cache/netbeans/8.2
  
  Para o bom desempenho do jogo é altemente recomendado que se utilize a plataforma do netbeans uma vez que os testes foram feitos
  somente para esta plataforma.
  
  Usuario: valdeci; julio; lucas
  senha: 123
